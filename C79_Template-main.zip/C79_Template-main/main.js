menuListArray = ["Pizza Vegetariana",//adicionar mais itens
                    ];

function getMenu(){
var htmldata;
//Completar o código
}

function addItem(){
var htmldata;
var item=document.getElementById("addItem").value;
//Completar o código

}

function addTop(){
//Completar o código
}